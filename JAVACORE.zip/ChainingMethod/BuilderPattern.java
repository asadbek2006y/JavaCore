package ChainingMethod;

public class BuilderPattern {
    public static void main(String[] args) {
        
    }
}
